## Directory Structure

- **Dockerfile** : Docker image to test module (requires .config,json)
- **install.sh** : install script to setup dependencies
- **KeyWordExtracion.ipynb** : R&D into relevancy score and training and evaluation of word2vec model
- **SamsRelevancy ** : python package for relevancy score
- **test.py** : demonstration of how to use SamsRelevancy

# Understanding Relevancy Score

The algorithm for relevancy score using a textrank algorithm to extract keywords and checks it similarity with topic in a word2vec model

> ***Algorithm still needs work to be done***

## Requirements

- Input : 

  | Field    | Description                                                  |
  | -------- | ------------------------------------------------------------ |
  | Text     | _str_ : The article data                                     |
  | Keywords | _list of str_ : set of topics based on which we'll get scores |

  

- Output :

  ```json
  "relevancy" : [
      {
          "topic" : "t1",
          "score" : 0.92
      },
      {
          "topic" : "t2",
          "score" : 0.83
      }
  ]
  ```
  
  For each article , we return a list of objects where each object contains a **topic** and the **relevancy score** of the article with that topic

## Understanding the approach

We have two parts of in the algorithm 

- textrank
- cosine similarity based on word2vec

### textrank

Explaination of textrank algorithm can be found here : [Keyword Extraction using textrank](https://www.google.com/url?sa=t&rct=j&q=&esrc=s&source=web&cd=&cad=rja&uact=8&ved=2ahUKEwj-r7Cb6IXqAhX1ILcAHWZBDCoQFjAAegQIBhAB&url=https%3A%2F%2Ftowardsdatascience.com%2Ftextrank-for-keyword-extraction-by-python-c0bae21bcec0&usg=AOvVaw06vKzOg8dEptwjYI4-LGaO)
So we have implemented the same here

example

> Civil defence used to involve air raid wardens, ambulance drivers and rescue teams. That was at the height of the Cold War, and the hot wars of the 20th century that preceded it. These days, it means taking the fight online — against hackers and cyber criminals looking to take down or ransom critical infrastructure, such as hospitals. The COVID-19 crisis has prompted Canadian IT professionals to form an all-volunteer cyber defence team to protect Canada's hospitals, health-care providers, municipalities and critical infrastructure from online attacks during the COVID-19 crisis. The SecDev Group, which has pioneered advanced analytics and cyber safety, has been spearheading the recruitment effort and has asked information technology professionals to step up and provide preventative measures and remedial services. 'Preying on fear' "Hackers are targeting ....... <truncated>

For this article the top keywords are 

```python
[
    ('cyber', 5.687784626952118)
    ('say', 4.352662271809556)
    ('hospital', 4.154044093200346)
    ('institution', 4.06456216588739)
    ('attack', 3.5736408189488604)
    ('work', 2.539049079635532)
    ('health', 2.3454757844158625)
    ('provide', 2.24505318601602)
    ('service', 2.10860199987329)
    ('care', 1.9988165127475495)
    ('network', 1.8735196934777676)
    ('professional', 1.8407695014394903)
    ('ransomware', 1.8078499033654682)
    ('group', 1.7239036755644443)
    ('volunteer', 1.7170856135462507)
    ('help', 1.6995538742725653)
    ('defence', 1.6859020820698989)
    ('provider', 1.6703678027706155)
    ('criminal', 1.6584377562915837)
    ('company', 1.5966475738698147)
    ('protect', 1.57408190056162)
    ('target', 1.5364910716841709)
]
```



## Cosine similarity using word2vec

Now we take the sum of the biased product of the textrank score of keyword and cosine similarity between each keyword and respective topic as the relevancy score

To check relevancy , we have trained a word2vec model implemented using gensim word2vec using the crawled data from our database and some Wikipedia articles from bag of words

Below is an image to show some important words plotted onto a graph , after reducing dimensions from 300 to 2 using a T-SNE model

![word2vec plot](../Sentiment_analysis/image-20200614231627394.png)

As with this method we a little amount of relevancy score for topics that don't have anything relevant with that topic , we check whether the normalized relevancy score is above a certain threshold

## Code Structure

So we have 

- **TextRank4Keyword**

  This class using the textrank algorithm and gives us the keywords from a article

- **relevancy_score**

  This class does the main process of using the keywords and the word2vec model to give relevancy score

- **s3_manager**

  This class will act as an interface to aws s3 where the models have been stored
  
- **SamsResourceError**

  This class is an exception class to better troubleshoot configuration errors from developer side
