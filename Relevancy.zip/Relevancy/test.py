from SamsRelevancy import *

pro = relevancy_score(local=True)
test = '''
Getty Images
A Florida man was sentenced to over two years in jail and forced to pay nearly $1.3 million in restitution for fraudulently accessing clients’ bank accounts and misappropriating close to $1.8 million in funds.
According to Danielle Battaglia of the Greensboro News & Record, Jason Christopher Jernigan was sentenced to two years and four months in prison with an additional three years of supervised release after pleading guilty to conspiracy to commit wire fraud and money laundering in North Carolina.
Jernigan and a partner, Michael Rowan, charged recently drafted NFL players an annual fee of between $15,000 to $50,000 to manage their finances and provide financial advice. Meanwhile, the clients gave the men access to their bank accounts. Jernigan then used this access to transfer money from the players’ accounts into that of their company accounts.
The players were not identified by name, only by initials, in the suit.
Rowan was sentenced to five years and five months in prison for wire fraud and filing a false 2011 tax return after pleading guilty in 2017 for his involvement in the matter.
'''
answers = pro.score(test)
for ans in sorted(answers , key=lambda i : i['score'] , reverse=True):
    print(f"topic : {ans['topic']:{30}} score : {ans['score']}")