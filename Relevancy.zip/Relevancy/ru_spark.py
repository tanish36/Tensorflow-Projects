from pyspark import SparkConf, SparkContext
from pyspark.sql import SparkSession
from pyspark.sql.functions import udf
from pyspark.sql.types import StringType , StructType , ArrayType , StructField , FloatType,IntegerType,MapType
import re

import pandas as pd
import numpy as np
import requests
import json
from SamsRelevancy import *
pro = relevancy_score(local=True)
def get_data_from_db():
    host = 'https://search-solytics-tzxvnvrvkscgklaedz5lr3iqxu.ap-south-1.es.amazonaws.com/news_test_list/_search'
    json_body = '''{
        "query": {
                "bool": {
                    "must_not": {
                        "exists":{
                            "field":"sentiment_ML"
                            }
                        }
                    }
                }
    }'''
    headers = {
        'Content-Type': 'application/json',
    }
    params = {
        'size':3
    }
    resp = requests.get(host,params=params, headers=headers, data=json_body)
    resp_text = json.loads(resp.text)
    document_list = []
    # print(resp)
    #for data in resp_text['hits']['hits']:
     #   content_list = {}
      #  content_list["id"] = data["_id"]
       # content_list["ents"] = entity_model.spark_extract(data["_source"]["Content"])
       # document_list.append(content_list) 
    
    for hit in resp_text['hits']['hits']:
            content_dic = {}
            content_dic["id"] = hit['_id']
            content_dic["content"] = hit['_source']['Content']
            content_dic["query"] = hit['_source']['query']
            document_list.append(content_dic)
    return document_list

conf = SparkConf().set('spark.executor.memory', '14G').set('spark.driver.memory', '45G').set('spark.driver.maxResultSize', '10G')
sc = SparkContext(conf=conf)
spark = SparkSession.builder.config(conf=conf).config("spark.driver.memory", "15g").getOrCreate()

d ={"aws_access_key_id" : "AKIA4IQTSJNFU73XW3VP","aws_secret_access_key" : "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"}

text = get_data_from_db()

schema = StructType([
    StructField("content",StringType(),False),
    StructField("id",StringType(),False),
    StructField("query",StringType(),False)
])
df = spark.createDataFrame(text,schema)
#df.show()

schema = ArrayType(StructType([
                               StructField('topic',StringType(),False),
                               StructField('score',FloatType(),False)

]))

generate_res = udf(pro.score,schema)

new_df = df.select("id" , generate_res("content").alias('output'))

new_df.show()

