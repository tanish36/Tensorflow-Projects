from gensim.test.utils import datapath
from gensim.models import Word2Vec, KeyedVectors
from .s3 import s3_manager
from .keywords import KeywordExtractor , normalize , normalized_mean
from nltk.corpus import stopwords

class relevancy_score:

  # In the initialization of class , this class will load model from s3 using the s3_manager . Also initializes keywords 
    def  __init__(self,local=False):
        manager = s3_manager()
        manager.verify_bucket()
        self.keyword_extractor = KeywordExtractor({"distance_threshold":1,
                   "num_keywords" : 20,
                   "distance_method": "editdistance",
                   "pair_diff_length":4,
                   "stopwords" : stopwords.words('english'),
                   "bigram_count_threshold":2,
                   "num_tokens":[1]})
        print(f"\tLoading Word2vec Model")
        if local:
            url = manager.download_word2vec()
        else:
            url = manager.word2vec_link()
        self.wv = KeyedVectors.load_word2vec_format(url, binary=True)
        self.bow = ['embezzlement',
                            'assets',
                            'crime',
                            'fraud',
                            'misconduct',
                            'tax_evasion',
                            'money_laundering',
                            'identity_theft',
                            'corruption',
                            'sanctions',
                            'cyber',
                            'terrorism',
                            'bribery']

    def get_BOW(self):
        return self.bow

    # for updating bag of words
    def set_BOW(self,new_):
        new_bow = []
        for n in new_:
            x = n.replace(' ','_')
            if x in self.wv.vocab:
                new_bow.append(x)
            elif x.lower() in self.wv.vocab:
                new_bow.append(x.lower())
            else:
                print(f"Topic not in bag of words : {n}")
        self.bow = new_bow

    def score(self,text):
        keywords = [(x.replace(' ','_'),y) for x,y in self.keyword_extractor.find_keywords(text, input_type = "text") if x.replace(' ','_') in self.wv.vocab]
        normalized = normalize([y for  x,y in keywords])
        BOW = self.bow
        pre = []
        array = []
        filtered_keywords = [(xy[0],z) for xy,z in zip(keywords,normalized) if z > 0.4]        
        for topic in BOW:
            sim_filtered = [x for x,y in filtered_keywords if self.wv.n_similarity([topic],[x]) > 0.4]
            keyword_scores = [y for x,y in filtered_keywords if x in sim_filtered]
            if len(sim_filtered) > 0:
                sim = self.wv.n_similarity([topic],sim_filtered)
            else:
                sim = 0
            topic_score = 0
            if len(keyword_scores) > 0:
                topic_score = sim * sum(keyword_scores)/len(keyword_scores)*10
            pre.append(
                {
                    "topic" : topic,
                    "score" : topic_score
                }
            )
            array.append(topic_score)
        final = [x for x in pre if x['score'] > normalized_mean(array)]
        return final
        