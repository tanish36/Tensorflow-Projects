import boto3
from os import listdir , mkdir
from os.path import isfile, join , isdir
from progress.bar import Bar
import json



'''Exception class to simplify exceptions'''
class SamsResourceError(Exception):

  def __init__(self,*args):
    if args:
        self.message = args[0]
    else:
        self.message = None
        
  def __str__(self):
    if self.message:
        return f'{self.message}'
    else:
        return f'Please check all resources'

'''This class helps load/download the latest models from the s3 bucket sams-models'''
class s3_manager:
  
  '''For now , till AWS credentials in server is not solved , This class requires a .config.json with credentials'''
  def __init__(self):
    try:
      with open('.config.json','r') as config:
        val = json.loads(config.read())
        ACCESS_ID = val['aws_access_key_id']
        ACCESS_KEY = val['aws_secret_access_key']
        self.s3 = boto3.resource('s3',aws_access_key_id=ACCESS_ID,aws_secret_access_key= ACCESS_KEY)
    except:
      raise SamsResourceError('.config.json missing')

  '''Checks whether the models are present in bucket and the bucket is accessible'''
  def verify_bucket(self):
      files = []
      try:
        bucket = self.s3.Bucket('sams-models')      
        for key in bucket.objects.all():
          files.append(key.key)
      except Exception as e:
        raise SamsResourceError(f'S3 bucket error : {e}')
      if 'word2vec.bin' not in files:
        raise SamsResourceError(f'word2vec.bin not found in {bucket}')
      print('S3 bucket correctly configured')

  '''downloads the export.pkl file from s3 into bert folder'''


  '''Returns the location link for gensim to load word2vec model from'''    
  def word2vec_link(self):
    try:
      with open('.config.json','r') as config:
        val = json.loads(config.read())
        ACCESS_ID = val['aws_access_key_id']
        ACCESS_KEY = val['aws_secret_access_key']
        url = 's3://' + ACCESS_ID + ":" + ACCESS_KEY + "@sams-models/word2vec.bin"
        return url
    except Exception as e:
      raise SamsResourceError(f'.config.json is missing')

  def download_word2vec(self):
    if isdir('w2v'):
      print('word2vec files already present')
    else:
      w2v_files = ['word2vec.bin',
        'bigrams',
        'trigrams'
      ]
      dir_name = 'w2v'
      bucket_name = 'sams-models'
      try:
        with Bar('Downloading files',max=len(w2v_files)) as bar:
          for w2v_file in w2v_files:
            bar.message = f"Downloading {w2v_file}"
            if isdir(dir_name):
              pass
            else:
              mkdir(dir_name)
            self.s3.meta.client.download_file(bucket_name, w2v_file, dir_name+'/'+w2v_file)
            bar.next()
          bar.finish()
      except Exception  as e:
        raise SamsResourceError(f'word2vec download error : {e}')
    return "w2v/word2vec.bin"