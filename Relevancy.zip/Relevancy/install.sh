#!/bin/bash

pip install --upgrade pip && \
pip install boto3 botocore && \
pip install spacy && \
python -m spacy download en_core_web_md && \
pip install progress && \
pip install gensim && \
pip install numpy
