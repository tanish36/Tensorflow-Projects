from gensim.test.utils import datapath
from gensim.models import Word2Vec, KeyedVectors
from .s3 import s3_manager
from .keywords import KeywordExtractor , normalize , normalized_mean
from nltk.corpus import stopwords

class relevancy_score:

  # In the initialization of class , this class will load model from s3 using the s3_manager . Also initializes keywords 
    def  __init__(self,local=False):
        manager = s3_manager()
        manager.verify_bucket()
        self.keyword_extractor = KeywordExtractor({"distance_threshold":1,
                   "num_keywords" : 30,
                   "distance_method": "editdistance",
                   "pair_diff_length":3,
                   "stopwords" : stopwords.words('english'),
                   "bigram_count_threshold":2,
                   "num_tokens":[1]})
        print(f"\tLoading Word2vec Model")
        if local:
            url = manager.download_word2vec()
        else:
            url = manager.word2vec_link()
        self.wv = KeyedVectors.load_word2vec_format(url, binary=True)
        self.bow = ['embezzlement',
                            'assets',
                            'crime',
                            'fraud',
                            'misconduct',
                            'tax_evasion',
                            'money_laundering',
                            'identity_theft',
                            'corruption',
                            'sanctions',
                            'cyber',
                            'trafficking',
                            'terrorism',
                            'bribery']

    def get_BOW(self):
        return self.bow

    # for updating bag of words
    def set_BOW(self,new_):
        new_bow = []
        for n in new_:
            x = n.replace(' ','_')
            if x in self.wv.vocab:
                new_bow.append(x)
            elif x.lower() in self.wv.vocab:
                new_bow.append(x.lower())
            else:
                print(f"Topic not in bag of words : {n}")
        self.bow = new_bow

    def score(self,text):
        keywords = [x.replace(' ','_') for x,y in self.keyword_extractor.find_keywords(text, input_type = "text") if x.replace(' ','_') in self.wv.vocab]
        BOW = self.bow
        pre = []
        array = []
        for topic in BOW:
            # print(topic)
            # [print(f"\t\t{topic:{25}} - {word:{25}} : {self.wv.n_similarity([topic],[word])}") for word,score in keywords]
            sim_filtered = [x for x in keywords if self.wv.n_similarity([topic],[x]) > 0.4]
            if len(sim_filtered) > 0:
                sim = max([self.wv.n_similarity([topic],[x]) for x in sim_filtered])
            else:
                sim = 0
            pre.append(
                {
                    "topic" : topic,
                    "score" : sim
                }
            )
            array.append(sim)
        final = [x for x in pre if x['score'] > normalized_mean(array+[0])]
        return final