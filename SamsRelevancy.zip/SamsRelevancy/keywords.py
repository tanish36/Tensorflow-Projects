from collections import OrderedDict
import numpy as np
from gensim.test.utils import datapath
from gensim.models import Word2Vec, KeyedVectors
from time import time
from spacy.lang.en.stop_words import STOP_WORDS

from mrakun import RakunDetector
import nltk
nltk.download('stopwords')
nltk.download('punkt')

from collections import defaultdict, Counter
import itertools
import numpy as np

class KeywordExtractor(RakunDetector):
    def __init__(self, hyperparameters, verbose=True):
        super().__init__(hyperparameters, verbose=True)
        if self.distance_method == "custom":
                from gensim.models import FastText
                self.pretrained_embedding_path = hyperparameters['pretrained_embedding_path']
                self.model = FastText.load(self.pretrained_embedding_path)

    def hypervertex_prunning(self, graph, distance_threshold, pair_diff_max = 2, distance_method = "editdistance"):
        self.to_merge = defaultdict(list)        
        for pair in itertools.combinations(graph.nodes(),2):
            abs_diff = np.abs(len(pair[0]) - len(pair[1]))
            if abs_diff  < pair_diff_max:
                if distance_method == "editdistance":
                    ed = self.calculate_edit_distance(pair[0],pair[1])
                elif distance_method == "fasttext" or distance_method == "custom":
                    ed = self.calculate_embedding_distance(pair[0],pair[1])
                if abs(ed) < distance_threshold:
                    self.to_merge[(abs_diff, ed)].append(pair)
        self.generate_hypervertices(graph)


def normalize(array):
    a = max(array)
    b = min(array)
    if a == b:
        return array
    new_array = [((x-b)/(a-b)) for x in array]
    return new_array

def normalized_mean(array):
    narray = normalize(array)
    return sum(narray)/len(narray)

