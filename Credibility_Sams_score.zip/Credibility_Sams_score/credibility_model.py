from credibility_score import *

# import dll

class sentspark:
    def __init__(self):
        self.manager = s3_manager()
        self.manager.verify_bucket()

        #Downloading model for fake score
        self.manager.download_fakeTokenizer()
        self.manager.download_json_model()
        self.manager.download_lstm()
        self.manager.download_tri_bi()

        #Downloading model for objective score
        self.manager.download_pipeline()

        #Downloading data for bias_rank
        self.manager.download_data()

        self.fake_score_object = FakeScore()
        self.bias_score_object = Bias_Score()
        self.rank_score_object = Ranks()
        self.obj_score_object = Objective_score()


    def fake_score(self,content):
        score = self.fake_score_object.fake_predictor(content)
        return score

    def google_alexa_score(self,url):
        score = self.rank_score_object.url_rank(url)
        return score
    
    def bias_score(self,source):
        score = self.bias_score_object.bias_score(source)
        return score
    
    def obj_score(self,title,content):
        score = self.obj_score_object.predictions(title,content)
        return score


content = """Page Content\nJS-4144\nThe U.S. Department of the Treasury today added a Swiss company and individual to its list of designees supporting the proliferation of weapons of mass destruction (WMD). Kohas AG and Jakob Steiger were designated pursuant to Executive Order 13382, an authority aimed at freezing the assets of WMD proliferators and their supporters.\n"North Korea\'s efforts to build and sell weapons of mass destruction depend on a vast network, the reach of which extends beyond Asia," said Stuart Levey, Treasury\'s Under Secretary for Terrorism and Financial Intelligence (TFI). "The Treasury will continue to track and combat this network aggressively to exclude North Korea\'s illicit activity from the financial system."\nKohas AG is an industrial supply wholesaler located in Switzerland that is named today for its ties to Korea Ryonbong General Corporation, which was designated by President Bush in the annex of E.O. 13382 on June 29, 2005. Nearly half of Kohas AG\'s shares are owned by a subsidiary of Korea Ryonbong General Corporation known as Korea Ryongwang Trading Corporation, which was previously designated by the Treasury on October 21, 2005. Jakob Steiger, a Swiss national, is the president of Kohas AG and owns the remainder of the company\'s shares.\nKohas AG acts as a technology broker in Europe for the North Korean military and has procured goods with weapons-related applications. Kohas AG and Jakob Steiger have been involved in activities of proliferation concern on behalf of North Korea since the company\'s founding in the late 1980s.\nToday\'s action prohibits transactions between the designees and any U.S. person and freezes any assets the designees may have under U.S. jurisdiction.\nBackground on Executive Order 13382\nToday\'s action builds on President Bush\'s issuance of E.O. 13382 on June 29, 2005. Recognizing the need for additional tools to combat the proliferation of WMD, the President signed the E.O. authorizing the imposition of strong financial sanctions against not only WMD proliferators, but also entities and individuals providing support or services to them. The E.O. carried with it an annex that designated eight entities operating in North Korea, Iran, and Syria for their support of WMD proliferation. The President at that time also authorized the Secretaries of Treasury and State to designate additional entities and individuals.\nSince the issuance of E.O. 13382, the Treasury has designated an additional 10 individuals and entities tied to North Korea proliferation and two Iranian entities facilitating proliferation.\nThe designations announced today are part of the ongoing interagency effort by the United States Government to combat WMD trafficking by blocking the property of entities and individuals that engage in proliferation activities and their support networks."""

model = sentspark()

