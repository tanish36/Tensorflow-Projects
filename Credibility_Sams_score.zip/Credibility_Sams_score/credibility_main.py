
import credibility_model as cred

import pandas as pd
import requests
import json

from pyspark.sql.functions import col
from pyspark.sql import Row
from pyspark.sql import SparkSession

from pyspark.sql.functions import *
from pyspark.sql.types import *

from pyspark.sql import SparkSession



def get_data_from_db():
    host = 'https://search-solytics-tzxvnvrvkscgklaedz5lr3iqxu.ap-south-1.es.amazonaws.com/news_test_list/_search'
    json_body = '''{
        "query": {
                "bool": {
                    "must_not": {
                        "exists":{
                            "field":"sentiment_ML"
                            }
                        }
                    }
                }
    }'''
    headers = {
        'Content-Type': 'application/json',
    }
    params = {
        'size':30
    }
    resp = requests.get(host,params=params, headers=headers, data=json_body)
    resp_text = json.loads(resp.text)
    document_list = []

    # print(resp)
    for data in resp_text['hits']['hits']:
        content_list = {}
        content_list["id"] = data["_id"]
        content_list["content"] = data["_source"]["Content"]
        content_list["url"] = data["_source"]["URL"]
        content_list["source"] = data["_source"]["Source"]
        content_list["title"] = data["_source"]["Title"]
        document_list.append(content_list)
    return document_list




def spark_data():
    data = get_data_from_db()
    df = pd.DataFrame(data)
    spark_df = spark.createDataFrame(df)
    return spark_df



def credibility_score(df):
    
    def score(row):
        final_coeff = {
                                'obj_score_coeff' : 0.3,
                                'fake_score_coeff' : 0.35,
                                'bias_score_coeff' : 0.25,
                                'google_rank_coeff' : 0.1,
                                'alexa_rank_coeff': -1*0.000001
                            }

        # giving a default values to all the scores
        fake_score = 0.5
        obj_score = 0.5
        google_score = 0.5
        alexa_score = 0.5
        bias_score = 0.5

        fake_score = cred.model.fake_score(row.content)
        google_score, alexa_score = cred.model.google_alexa_score(row.url)
        bias_score = cred.model.bias_score(row.source)
        obj_score = cred.model.obj_score(row.title,row.content)

        final_score = fake_score[0,0]*final_coeff['fake_score_coeff']                 + bias_score*final_coeff['bias_score_coeff']                     + google_score*final_coeff['google_rank_coeff']                         +alexa_score * final_coeff['alexa_rank_coeff']                            + obj_score[0]*final_coeff['obj_score_coeff']  
        idd = row.id
        contentt = row.content
        sourcee = row.source
        titlee = row.title
        urll = row.url
        credibilityy = float(final_score)
        return Row(id=idd,content=contentt,source=sourcee,title=titlee,url=urll,credibility=credibilityy)
    
    data = df.rdd.map(score)
    schema = StructType([
        StructField("id",StringType(),False),
        StructField("content",StringType(),False),
        StructField("source",StringType(),False),
        StructField("title",StringType(),False),
        StructField("url",StringType(),False),
        StructField("credibility",FloatType(),False)
    ])
    result = spark.createDataFrame(data,schema)
    return result


spark = SparkSession.builder \
    .master("local") \
    .appName("Word Count") \
    .config("spark.some.config.option", "some-value") \
    .getOrCreate()

data = get_data_from_db()
df = spark_data()

ans = credibility_score(df)
ans.show()






