import transformers
from transformers import BertModel, BertTokenizer, AdamW, get_linear_schedule_with_warmup
import torch
from torch import nn
import torch.nn.functional as F

import numpy as np
import pandas as pd

RANDOM_SEED = 42
np.random.seed(RANDOM_SEED)
torch.manual_seed(RANDOM_SEED)
PRE_TRAINED_MODEL_NAME = 'bert-base-cased'

class SentimentClassifier(nn.Module):

  def __init__(self, n_classes):
    super(SentimentClassifier, self).__init__()
    self.bert = BertModel.from_pretrained(PRE_TRAINED_MODEL_NAME)
    self.drop = nn.Dropout(p=0.3)
    self.out = nn.Linear(self.bert.config.hidden_size, n_classes)
  
  def forward(self, input_ids, attention_mask):
    _, pooled_output = self.bert(
      input_ids=input_ids,
      attention_mask=attention_mask
    )
    output = self.drop(pooled_output)
    return self.out(output)

class sentiment:
    def __init__(self):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        self.model = torch.load('bert/model.pt',map_location=device)
        PRE_TRAINED_MODEL_NAME = 'bert-base-cased'
        self.tokenizer = BertTokenizer.from_pretrained(PRE_TRAINED_MODEL_NAME)

    def score(self,text):
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
        encoding = self.tokenizer.encode_plus(
            text,
            max_length=250,
            add_special_tokens=True, # Add '[CLS]' and '[SEP]'
            return_token_type_ids=False,
            pad_to_max_length=True,
            return_attention_mask=True,
            return_tensors='pt',  # Return PyTorch tensors
        )
        input_ids = encoding['input_ids'].to(device)
        attention_mask = encoding['attention_mask'].to(device)
        outputs = self.model(
            input_ids=input_ids,
            attention_mask=attention_mask
        )
        _, preds = torch.max(outputs, dim=1)
        probs = F.softmax(outputs, dim=1)
        category = preds.numpy()[0]
        pos_prob = probs.detach().numpy()[0][2]
        neu_prob = probs.detach().numpy()[0][1]
        neg_prob =probs.detach().numpy()[0][0]
        if category == 0:
            return ("NEGATIVE",neg_prob)
        elif category == 2:
            return ("POSITIVE",pos_prob)
        else:
            return ("NEUTRAL" , neu_prob)
        # else:
        #     if pos_prob - neg_prob > 0.7*pos_prob:
        #         return ("NEUTRAL_POSITIVE" , neu_prob+pos_prob)
        #     elif neg_prob - pos_prob > 0.7*neg_prob:
        #         return ("NEUTRAL_NEGATIVE" , neu_prob+neg_prob)
        #     else:
        #         return ("NEUTRAL" , neu_prob)