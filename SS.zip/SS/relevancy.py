from gensim.test.utils import datapath
from gensim.models import Word2Vec, KeyedVectors
from time import time
import nltk
from nltk.tokenize import sent_tokenize
from gensim.models.phrases import Phrases, Phraser
import re
from spacy.lang.en.stop_words import STOP_WORDS

'''This function gives us relevant text based on word2vec and similarity'''
class relevancy:

  '''For this we need to load a langauage model for parsing and the word2vec model for similarity'''
  def __init__(self,url):
    print(f"\tLoading nltk sentence tokenizer")
    nltk.download('punkt')
    print(f"\tLoading Word2vec Model")
    self.wv = KeyedVectors.load_word2vec_format(url, binary=True)
    self.keywords = ['embezzlement',
                      'assets',
                      'crime',
                      'fraud',
                      'misconduct',
                      'tax_evasion',
                      'money_laundering',
                      'identity_theft',
                      'corruption',
                      'sanctions',
                      'cyber',
                      'terrorism',
                      'bribery']
    self.bigrams = Phraser.load(url.replace('word2vec.bin','bigrams'))
    self.trigrams = Phraser.load(url.replace('word2vec.bin','trigrams'))
  
  def preprocess(self,text):
    text = re.sub(r'\S*@\S*\s?', '', text)
    text = re.sub(r'\s+', ' ', text)
    text = re.sub('[,\.!?]','',text)
    text = re.sub('[0-9-\/]+',' ',text)
    text = [token for token in text.split() if token not in STOP_WORDS]
    text = self.trigrams[self.bigrams[text]]
    return text
  
  '''The main process where we extract relevant text
      More on this in README
  '''
  def relevant_text(self,text):
    output = {}
    keywords = [x for x in self.keywords if x in self.wv.vocab]
    for sent in sent_tokenize(text):
      tokens = [x for x in self.preprocess(sent) if x in self.wv.vocab]
      if len(tokens) > 0:
        for keyword in keywords:
          sim = self.wv.n_similarity([keyword],tokens)
          if sim > 0.4:
            if keyword in output:
              output[keyword] += sent.strip() + '\n'
            else:
              output[keyword] = sent.strip() + '\n'
    return output
