from .score import *
from .s3 import * 
from .sentiment import *
from .entity import *
from .relevancy import *

# To use this package , please use
#           from SamsSentiment import SentimentScore

