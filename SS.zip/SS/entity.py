import en_core_web_md
import re
import neuralcoref
import spacy
from pathlib import Path

'''This class performs the entity extraction process from text'''
class entity:
  '''We load two models and then combine them along with neuralcoref to get our final language model that performs all the tasks'''
  def __init__(self):
    output_dir="sams_en_ner_lg"
    output_dir = Path(output_dir)
    print(f"\tLoading Custom Spacy NER model")
    self.ner = spacy.load(output_dir , disable=['tagger', 'parser'])
    print(f"\tLoading Spacy language model for parsing")
    self.nlp = en_core_web_md.load()
    self.nlp.pipeline = [
            ('ner' , self.ner.entity),
            ('parser' , self.nlp.parser)
    ]
    print(f"\tSetting up spacy pipeline with neuralcoref")
    coref = neuralcoref.NeuralCoref(self.ner.vocab)
    self.nlp.add_pipe(coref, name='neuralcoref')

  '''Utility function to combine names of single individual'''
  def in_(self,entity,tag):
    tag_list = tag.lower().replace("'s","").split(" ")
    ent_list = entity.lower().split()
    for ent in ent_list:
      if ent in tag_list:
        return True
    return False
    
  '''The main process of extracting entities 
      more on this in README
  '''
  def extract(self,text):
    doc = self.nlp(text)
    temp = [x.text for x in doc.ents]
    end = set()
    for t1 in temp:
      x = t1.strip().replace("'s","")
      if x not in end:
        flag = 0
        elem = ''
        for y in end:
          if y in x:
            flag = 1
            elem = y
            break
          if x in y:
            flag = 2
            elem = y
            break
        if flag == 0:
          end.add(x)      
        elif flag == 1:
          end.remove(elem)
          end.add(x)
    ents1 = [re.sub(r'[\W\d]',' ',x).strip() for x in end]
    final = {}
    for ent in end:
      final[ent] = ""
    text = doc._.coref_resolved
    for sent in self.nlp(text).sents:
      for ent in final:
        if self.in_(ent,sent.text):
          final[ent] += sent.text
    return final

  def spark_extract(self,text):
    final = self.extract(text)
    result = []
    for ent in final:
        result.append({
            "entity" : ent,
            "text" : final[ent]
        })
    return result

    