from .s3 import s3_manager
from .entity import entity
from .relevancy import relevancy
from .sentiment import sentiment

'''This is the class called as SentimentScore'''
class sentiment_score:

  '''Calls all classes and intitate s3 manager'''
  def __init__(self,local=False):
    self.manager = s3_manager()
    self.manager.verify_bucket()
    self.manager.download_ner()
    print(f"Setting up entity extraction")
    self.ent = entity()
    print(f"Setting up relevancy based extraction")
    if local:
      self.rel = relevancy(self.manager.download_word2vec())
    else:
      self.rel = relevancy(self.manager.word2vec_link())
    self.manager.download_learner()
    print(f"Setting up sentiment classification model")
    self.sent = sentiment()

  '''Gives Sentiment Score
      for more details , refer README
  '''
  def score(self,article):
    final = self.ent.extract(article)
    for person in final:
      final[person] = self.rel.relevant_text(final[person])
      for topic in final[person]:
        final[person][topic] = self.sent.score(final[person][topic])
    simplified = []
    for person in final:
      for topic in final[person]:
        simplified.append({
            "name" : person,
            "topic" : topic.replace('_',''),
            "sentiment" : final[person][topic][0],
            "score" : final[person][topic][1]
        })
    return simplified
